---
layout: post
title: "Sample Link Post"
excerpt: "Example and code for using link posts."
categories: articles
tags: [sample-post, link-post]
link: http://mademistakes.com  
---

So Simple Theme now supports **link posts**, made famous by John Gruber. To activate just add `link: http://url-you-want-linked` to the post's YAML front matter and you're done.