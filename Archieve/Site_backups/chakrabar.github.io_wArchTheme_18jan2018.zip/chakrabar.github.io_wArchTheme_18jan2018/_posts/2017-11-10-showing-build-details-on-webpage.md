---
layout: default
title: "Showing build details on .Net web page"
date: 2017-11-10
tags: tech tips notes
---

## Cool stuffs ahead :)